"""
settings_base is a dummy django settings file to
run tests using django manage.py test
"""
