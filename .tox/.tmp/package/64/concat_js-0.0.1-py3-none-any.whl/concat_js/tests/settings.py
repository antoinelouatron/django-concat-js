from pathlib import Path
from settings_base import *

CONCAT_JS = {
    "CONCAT_ROOT": Path("."),
    "JSON_DEPS": BASE_DIR / "tests/concat.json"
}